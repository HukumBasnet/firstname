<div class="loader">
    <img src="<?php echo e(asset('01-progress.gif')); ?>" class="loader-gif" />
</div>