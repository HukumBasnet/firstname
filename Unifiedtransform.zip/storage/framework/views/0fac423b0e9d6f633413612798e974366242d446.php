<?php $__env->startSection('title', __('Impersonate')); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="panel panel-default">
        <table class="table">
            <thead>
                <tr>
                    <th><?php echo app('translator')->getFromJson('ID'); ?></th>
                    <th><?php echo app('translator')->getFromJson('Name'); ?></th>
                    <th><?php echo app('translator')->getFromJson('Role'); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $other_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="POST" action="<?php echo e(url('/user/config/impersonate')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <tr>
                        <td><?php echo e($other_user->id); ?></td>
                        <td><?php echo e($other_user->name); ?></td>
                        <td><?php echo e($other_user->role); ?></td>
                        <td>
                            <input type="hidden" name="id" value="<?php echo e($other_user->id); ?>" />
                            <button class="btn btn-default"><?php echo app('translator')->getFromJson('Impersonate'); ?></button>
                        </td>
                    </tr>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>