<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="page-panel-title"><?php echo app('translator')->getFromJson('Dashboard'); ?></div>

                <div class="panel-body">
                    <a class="btn btn-danger btn-lg btn-block" href="<?php echo e(route('schools.index')); ?>" role="button">
                        <?php echo app('translator')->getFromJson('Manage Schools'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>