<form class="form-horizontal" action="<?php echo e(url('library/issue-books')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group<?php echo e($errors->has('student_code') ? ' has-error' : ''); ?>">
        <label for="student_code" class="col-md-4 control-label"><?php echo app('translator')->getFromJson('Student Code'); ?></label>

        <div class="col-md-6">
            <input id="student_code" type="text" class="form-control" name="student_code" value="<?php echo e(old('student_code')); ?>"
                placeholder="<?php echo app('translator')->getFromJson('Student Code'); ?>" required>

            <?php if($errors->has('student_code')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('student_code')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group<?php echo e($errors->has('book_code') ? ' has-error' : ''); ?>">
        <label for="book_code" class="col-md-4 control-label"><?php echo app('translator')->getFromJson('Book Title'); ?> &amp; <?php echo app('translator')->getFromJson('Code'); ?> (<small><?php echo app('translator')->getFromJson('Type'); ?> & <?php echo app('translator')->getFromJson('Search by Name/Code.'); ?>
                <?php echo app('translator')->getFromJson('You can Select Multiple Books'); ?> (<i><?php echo app('translator')->getFromJson('Maximum'); ?> 10 <?php echo app('translator')->getFromJson('books'); ?></i>)</small>)</label>

        <div class="col-md-6">
            <select id="book_code" class="form-control" multiple name="book_id[]">
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?> - <?php echo e($book->book_code); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-group<?php echo e($errors->has('issue_date') ? ' has-error' : ''); ?>">
        <label for="issue_date" class="col-md-4 control-label"><?php echo app('translator')->getFromJson('Issue Date'); ?></label>

        <div class="col-md-6">
            <input id="issue_date" class="form-control datepicker" name="issue_date" value="<?php echo e(old('issue_date')); ?>"
                placeholder="<?php echo app('translator')->getFromJson('Issue Date'); ?>" required>

            <?php if($errors->has('issue_date')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('issue_date')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group<?php echo e($errors->has('return_date') ? ' has-error' : ''); ?>">
        <label for="return_date" class="col-md-4 control-label"><?php echo app('translator')->getFromJson('Return Date'); ?></label>

        <div class="col-md-6">
            <input id="return_date" class="form-control datepicker" name="return_date" value="<?php echo e(old('return_date')); ?>"
                placeholder="<?php echo app('translator')->getFromJson('Return Date'); ?>" required>

            <?php if($errors->has('return_date')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('return_date')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-4 col-sm-8">
            <button type="submit" class="btn btn-danger"><?php echo app('translator')->getFromJson('Save'); ?></button>
        </div>
    </div>
</form>

<script>
    $(function () {
        $('#book_code').chosen({
            max_selected_options: 10,
            display_selected_options: true,
            width: "100%"
        });
    })
</script>
