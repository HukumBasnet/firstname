<?php $__env->startComponent('mail::message'); ?>

# <?php echo app('translator')->getFromJson('Welcome to'); ?> <?php echo e(config('app.name')); ?>


<?php echo app('translator')->getFromJson('Hi'); ?> <?php echo e($name); ?>,

<?php echo app('translator')->getFromJson('We are glad to have you on board.'); ?>

<?php if(!is_null($password)): ?>
<?php echo app('translator')->getFromJson('Your login details are as follows:'); ?>

**<?php echo app('translator')->getFromJson('Email'); ?>**: <?php echo e($email); ?>


**<?php echo app('translator')->getFromJson('Password'); ?>**: <?php echo e($password); ?>


<?php echo app('translator')->getFromJson('You can change your password once logged-in.'); ?>
<?php else: ?>
<?php echo app('translator')->getFromJson('Please ask site administrator to know your login access.'); ?>
<?php endif; ?>

<?php $__env->startComponent('mail::button', ['url' => url('login')]); ?>
<?php echo app('translator')->getFromJson('Visit site'); ?>
<?php echo $__env->renderComponent(); ?>

<?php echo app('translator')->getFromJson('Thanks'); ?>,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>